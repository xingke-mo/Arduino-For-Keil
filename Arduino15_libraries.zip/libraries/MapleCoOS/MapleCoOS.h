#ifndef _COOS_H_
#define _COOS_H_

#include "WProgram.h"
extern "C" {
#include "utility/CoOS.h"
}

#define TASK_STK_SIZE   128 /*!< Define stack size. */

#endif
